Nom d'etudiant: Daniel Gebara et Jad Mroueh
Numero d'etudiant: 300401006 et 300425804
Code de cours: ITI1521

Aucune declaration


Ce dossier contient les fichiers Java pour le devoir 1.
Avec l'objectif de manipuler des nombres, des tableaux et de simuler des jeux de dés, en démontrant l'utilisation de boucles, des conditions et de manipulations de tableaux.
