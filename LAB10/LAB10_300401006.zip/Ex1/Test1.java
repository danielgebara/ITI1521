package LAB10.Ex1;

class Test1 {

    public static void main( String[] args ) {

    DoublyLinkedList maList = new DoublyLinkedList();
    if ( maList.size() != 0 )
      System.out.println( "List not empty " );
    else    
      System.out.println( "List empty "  );
    }
}

