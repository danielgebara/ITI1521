package LAB2;

// ITI 1521
// Daniel Gebara
// 300401006
// TestBook part A

public class TestBookA {
    public static void main(String[] args) {
     BookA book1 = new BookA("E.B.Koffman ", "Abstraction and Design Using Java");
     book1.affiche();
     System.out.println();
     System.out.println(book1);
    }  
}