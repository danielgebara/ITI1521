package LAB11.Ex3;

public interface Iterator<E> {
    int next();
    boolean hasNext();
}
