package LAB11.Ex1;

public interface Iterator {
    boolean hasNext();
    int next();
    void add( int elem );
}
