package LAB11.Ex2;

public interface Iterator {
    boolean hasNext();
    int next();
    void add( int elem );
}
